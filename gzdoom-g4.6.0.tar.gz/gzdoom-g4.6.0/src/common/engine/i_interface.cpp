#include "i_interface.h"

// Some global engine variables taken out of the backend code.
SystemCallbacks sysCallbacks;
FString endoomName;
bool batchrun;
float menuBlurAmount;

